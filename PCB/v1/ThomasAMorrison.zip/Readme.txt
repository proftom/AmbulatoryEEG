For wed 28th manufacture 0.8mm train.

All holes plated through hole. 


If DRC are small and likely to cause no problem, please continue manfacture. Please use your best judgement. 
I manufactured this board at home a couple of weeks ago, with some even finer tracks, have made this easier, so should be fine for you guys. Only having it done professionally to improve RF, and make use of through hole technology.   
Please try to manufacture - need this by next week (wed 4th/thurs 5th june) :)

I also include the .brd file (EAGLE), if that helps

Please ring 07511117866 for any questions.